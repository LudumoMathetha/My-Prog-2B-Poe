﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace Contract_Monthly_Claim_System.Controllers
{
    public class AccountController : Controller
    {
        // Hardcoded credentials from your request
        private readonly Dictionary<string, (string password, string role)> Users = new()
        {
            {"Ludumo", ("Linathi19", "Lecturer")},
            {"Chulumanco", ("Iviwe26", "Coordinator")},
            {"Aviwe", ("Lukhanyo18", "Manager")}
        };

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Please enter both username and password.";
                return View();
            }

            if (Users.TryGetValue(username, out var entry) && entry.password == password)
            {
                HttpContext.Session.SetString("Username", username);
                HttpContext.Session.SetString("UserRole", entry.role);
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid credentials.";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}

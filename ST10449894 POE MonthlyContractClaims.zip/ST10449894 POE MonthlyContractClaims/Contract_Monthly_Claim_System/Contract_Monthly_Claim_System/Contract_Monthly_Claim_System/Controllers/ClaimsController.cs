﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Contract_Monthly_Claim_System.Models;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace Contract_Monthly_Claim_System.Controllers
{
    public class ClaimsController : Controller
    {
        // NOTE: For demo/testing we use a static list. Replace with DB context for production.
        private static List<Claim> _claims = new List<Claim>();
        private static int _idCounter = 1;
        private readonly IWebHostEnvironment _env;

        public ClaimsController(IWebHostEnvironment env)
        {
            _env = env;
        }

        // Lecturer: Create new claim with document upload
        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Lecturer")
                return RedirectToAction("Index", "Home");

            return View();
        }

        [HttpPost]
        public IActionResult Create(string title, string description, IFormFile document)
        {
            var username = HttpContext.Session.GetString("Username");
            if (username == null) return RedirectToAction("Login", "Account");

            string savedPath = null;
            if (document != null && document.Length > 0)
            {
                var uploads = Path.Combine(_env.WebRootPath, "uploads");
                if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);
                var fileName = $"{System.Guid.NewGuid()}_{Path.GetFileName(document.FileName)}";
                var filePath = Path.Combine(uploads, fileName);
                using (var fs = new FileStream(filePath, FileMode.Create))
                {
                    document.CopyTo(fs);
                }
                savedPath = $"/uploads/{fileName}";
            }

            var claim = new Claim
            {
                Id = _idCounter++,
                Title = title,
                Description = description,
                DocumentPath = savedPath,
                CreatedBy = username,
                Status = ClaimStatus.PendingCoordinator
            };
            _claims.Add(claim);

            return RedirectToAction("MyClaims");
        }

        // Lecturer: view own claims
        public IActionResult MyClaims()
        {
            var username = HttpContext.Session.GetString("Username");
            if (username == null) return RedirectToAction("Login", "Account");

            var mine = _claims.Where(c => c.CreatedBy == username).OrderByDescending(c => c.CreatedAt).ToList();
            return View(mine);
        }

        // Coordinator & Manager: view pending claims
        public IActionResult Pending()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role == null) return RedirectToAction("Login", "Account");

            if (role == "Coordinator")
            {
                var pending = _claims.Where(c => c.Status == ClaimStatus.PendingCoordinator).ToList();
                return View("Pending", pending);
            }
            else if (role == "Manager")
            {
                // Manager should see claims approved by coordinator and awaiting final approval
                var forFinal = _claims.Where(c => c.Status == ClaimStatus.ApprovedByCoordinator).ToList();
                return View("Pending", forFinal);
            }

            return RedirectToAction("Index", "Home");
        }

        // Coordinator approves
        [HttpPost]
        public IActionResult Approve(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var claim = _claims.FirstOrDefault(c => c.Id == id);
            if (claim == null) return NotFound();

            if (role == "Coordinator" && claim.Status == ClaimStatus.PendingCoordinator)
            {
                claim.Status = ClaimStatus.ApprovedByCoordinator;
                return RedirectToAction("Pending");
            }
            else if (role == "Manager" && claim.Status == ClaimStatus.ApprovedByCoordinator)
            {
                claim.Status = ClaimStatus.ApprovedByManager;
                claim.IsPaid = true;
                return RedirectToAction("Pending");
            }

            return Forbid();
        }

        [HttpPost]
        public IActionResult Reject(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var claim = _claims.FirstOrDefault(c => c.Id == id);
            if (claim == null) return NotFound();

            if (role == "Coordinator" && claim.Status == ClaimStatus.PendingCoordinator)
            {
                claim.Status = ClaimStatus.Rejected;
                return RedirectToAction("Pending");
            }
            else if (role == "Manager" && claim.Status == ClaimStatus.ApprovedByCoordinator)
            {
                claim.Status = ClaimStatus.Rejected;
                return RedirectToAction("Pending");
            }

            return Forbid();
        }

        // Optional: download document
        public IActionResult Download(int id)
        {
            var claim = _claims.FirstOrDefault(c => c.Id == id);
            if (claim == null || string.IsNullOrEmpty(claim.DocumentPath)) return NotFound();

            var filePath = Path.Combine(_env.WebRootPath, claim.DocumentPath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
            var contentType = "application/octet-stream";

            return PhysicalFile(filePath, contentType, Path.GetFileName(filePath));
        }
    }
}


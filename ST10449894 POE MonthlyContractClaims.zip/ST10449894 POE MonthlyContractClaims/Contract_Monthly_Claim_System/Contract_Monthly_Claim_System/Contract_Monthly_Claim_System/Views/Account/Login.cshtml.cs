using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Contract_Monthly_Claim_System.Views.Account
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

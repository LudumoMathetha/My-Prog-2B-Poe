﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Contract_Monthly_Claim_System.Models
{
    public enum ClaimStatus { PendingCoordinator, Rejected, ApprovedByCoordinator, ApprovedByManager }

    public class Claim
    {
        public int Id { get; set; }
        [Display(Name = "Title")]
        public string Title { get; set; }
        public string Description { get; set; }

        // New
        public string DocumentPath { get; set; }
        public string CreatedBy { get; set; }
        public ClaimStatus Status { get; set; } = ClaimStatus.PendingCoordinator;
        public bool IsPaid { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
